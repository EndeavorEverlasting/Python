import pandas as pd
from datetime import datetime


def find_duplicates(input_file):
  # Read the Excel file
  df = pd.read_excel(input_file, skiprows=1)

  # Find records where both 'FlrPlnN' and 'FlrPlnD' match on two or more occurrences
  duplicates_n_d = df.groupby(['FlrPlnN',
                               'FlrPlnD']).filter(lambda x: len(x) >= 2)

  # Find records where both 'FlrPlnD' and 'ID' match on two or more occurrences
  duplicates_d_id = df.groupby(['FlrPlnD', 'ID']).filter(lambda x: len(x) >= 2)

  # Finds records that are missing floor plans from the ITAM spreadsheets
  duplicates_d_id = df.groupby(['FlrPlnD', 'ID']).filter(lambda x: len(x) >= 2)

  # Concatenate the results
  duplicates = pd.concat([duplicates_n_d, duplicates_d_id], ignore_index=True)

  if not duplicates.empty:
    # Add a new column for unique identifier (assuming you have some identifier)
    duplicates.insert(0, 'Unique Identifier', range(1, len(duplicates) + 1))

    # Get the current date
    current_date = datetime.now().strftime('%Y-%m-%d')

    # Output duplicates with date in the file name
    output_file = f'duplicates_at_{input_file}_{current_date}.csv'
    duplicates.to_csv(output_file, index=False)
    print(f'Duplicates found and saved in {output_file}')
  else:
    print('No duplicates found.')


# Example usage for Finding Duplicates

# input_file = 'Northern Westchester.xlsx'

# Calls duplicate functionality without other types of Discrepancies
# find_duplicates(input_file)
