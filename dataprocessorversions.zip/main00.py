import pandas as pd
from datetime import datetime

### ### ###

### ### ###
def find_duplicates_and_missing_data(input_file):
  # Get the current date
  current_date = datetime.now().strftime('%Y-%m-%d')
  # Read the Excel file
  df = pd.read_excel(input_file, skiprows=1)

  # Find records where both 'FlrPlnN' and 'FlrPlnD' match on two or more occurrences
  duplicates_n_d = df.groupby(['Flr Pln N',
                               'Flr Pln D']).filter(lambda x: len(x) >= 2)

  # Find records where both 'FlrPlnD' and 'Department' match on two or more occurrences
  duplicates_d_id = df.groupby(['Flr Pln D',
                                'Department']).filter(lambda x: len(x) >= 2)

  # Concatenate the results
  duplicates = pd.concat([duplicates_n_d, duplicates_d_id], ignore_index=True)

  if not duplicates.empty:
    # Add a new column for unique identifier (assuming you have some identifier)
    duplicates.insert(0, 'Unique Identifier', range(1, len(duplicates) + 1))

    # Output duplicates with date in the file name
    output_file = f'duplicates_at_{input_file}_{current_date}.csv'
    duplicates.to_csv(output_file, index=False)
    print(f'Duplicates found and saved in {output_file}')
  else:
    print('No duplicates found.')

  # Find records with missing data in a specific column (e.g., 'ColumnX')
  missing_data = df[df['Flr Pln N'].isna()]

  if not missing_data.empty:
    # Output records with missing data to a CSV file
    missing_data.to_csv('missing_data_at{current_date}.csv', index=False)
    print(
        f'Records with missing data saved in missing_{current_date}_{input_file}.csv'
    )
  else:
    print('No records with missing data found.')


# Example usage for dupes and missing floor plans
input_file = 'LHGVh - 11 AM.xlsx'

find_duplicates_and_missing_data(input_file)
