import pandas as pd

# Load the CSV file
df = pd.read_csv('FixDup8Tower.csv', header=1)

# Choose the column you want to check for duplicates
column_name = 'Flr Pln D'

# Find duplicate entries in the chosen column
duplicate_entries = df[df.duplicated(subset=[column_name], keep=False)]

# Group duplicates into tuples of two or three
grouped_duplicates = []
seen = set()

for _, row in duplicate_entries.iterrows():
    value = row[column_name]
    if value in seen:
        continue
    duplicates = list(duplicate_entries[duplicate_entries[column_name] == value].index)
    if len(duplicates) >= 2:  # Adjust this threshold for tuples of different sizes
        grouped_duplicates.append(tuple(duplicates))
        seen.update(duplicates)

# Print the grouped duplicates with 'Flr Pln D' values
print("Grouped duplicates:")
for group in grouped_duplicates:
    duplicate_values = [df.loc[i, column_name] for i in group]
    print(f"Duplicate values: {duplicate_values}")
