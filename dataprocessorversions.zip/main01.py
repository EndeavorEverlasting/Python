import os
import pandas as pd
from datetime import datetime


def find_duplicates_and_missing_data(input_file):
  current_date = datetime.now().strftime('%Y-%m-%d')
  current_time = datetime.now().strftime('%H%M%S')
  df = pd.read_excel(input_file, skiprows=1)

  duplicates_n_d = df.groupby(['Flr Pln N',
                               'Flr Pln D']).filter(lambda x: len(x) >= 2)
  duplicates_d_id = df.groupby(['Flr Pln D',
                                'Department']).filter(lambda x: len(x) >= 2)
  dupe_d_l = df.groupby(['Flr Pln D',
                         'Flr Pln L']).filter(lambda x: len(x) >= 2)
  duplicates = pd.concat([duplicates_n_d, duplicates_d_id, dupe_d_l],
                         ignore_index=True).drop_duplicates(subset=['ID'])
  missing_data = df[df['Flr Pln N'].isna()]
  entries_to_include = df[~df['Flr Pln D'].fillna('').astype(str).str.
                          startswith(('P', 'S'))]

  # Filling empty cells in 'Flr Pln D' with a blank string
  entries_to_include.loc[:,
                         'Flr Pln D'] = entries_to_include['Flr Pln D'].fillna(
                             '')

  combined_data = pd.concat([duplicates, missing_data, entries_to_include],
                            ignore_index=True).drop_duplicates(subset=['ID'])

  if not combined_data.empty:
    combined_data.insert(0, 'Unique Identifier',
                         range(1,
                               len(combined_data) + 1))

    def determine_flagging_reason(row):
      reasons = []

      if not pd.notna(row['Flr Pln N']):
        reasons.append('Missing Flr Pln N')
      if pd.notna(row['Flr Pln D']):
        if pd.notna(row['Department']):
          reasons.append('Duplicate based on Flr Pln D and Department')
        if pd.notna(row['Flr Pln L']):
          reasons.append('Duplicate based on Flr Pln D and Flr Pln L')
        if row['Flr Pln D'].startswith(('L', 'W')):
          if (row['WS_Mon_Make_1'] in (None, '')
              or row['WS_Mon_Mod_1'] in (None, '')):
            reasons.append('Incorrect Monitor Info')
        if not pd.notna(row['Flr Pln D']) or not str(
            row['Flr Pln D']).strip() or str(
                row['Flr Pln D']).strip()[0].isdigit():
          reasons.append('Incorrect Designator')

      if reasons:
        print(
            f"For record with ID {row['ID']}, reasons are: {', '.join(reasons)}"
        )
        return ', '.join(reasons)
      else:
        return 'Unknown Reason'

    combined_data['Flagging Reason'] = combined_data.apply(
        determine_flagging_reason, axis=1)

    file_name = os.path.splitext(input_file)[0]
    output_file = f'combined_data_{file_name}_{current_time}.csv'
    combined_data.to_csv(output_file, index=False)
    print(f'Data saved in {output_file}')
  else:
    print('No data found.')


# Example usage
input_file = 'PBMC-NOV2.xlsx'
find_duplicates_and_missing_data(input_file)
