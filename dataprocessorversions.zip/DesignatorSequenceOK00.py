import pandas as pd
from datetime import datetime

def generate_sequential_designators(input_file):
    df = pd.read_excel(input_file, skiprows=1)

    # Extract the hospital code, address, floor, and section information from "Flr Pln N"
    naming_info = df['Flr Pln N'].str.extract(r'([A-Z]+[h,a])-(.*?)\s*Floor(\d+)-Section(\d+)')
    df['Hospital Code'] = naming_info[0]
    df['Address'] = naming_info[1]
    df['Floor'] = naming_info[2].astype(int, errors='ignore').fillna(0)  # Convert to int, handle NaNs, and replace with 0
    df['Section'] = naming_info[3].astype(int, errors='ignore').fillna(0)  # Convert to int, handle NaNs, and replace with 0

    # Define a dictionary to map device types to prefixes
    device_types = {
        'W': 'W',  # Workstations
        'L': 'L',  # Laptops
        'P': 'P',  # Printers
        'S': 'S',  # Special Printers
    }

    # Determine device type based on "Hostname" or "Type" columns
    def get_device_type(row):
        for prefix, device_type in device_types.items():
            if pd.notna(row['Hostname']) and row['Hostname'].startswith(device_type):
                return prefix
            if pd.notna(row['Type']) and row['Type'] == 'Printer':
                return 'P'
        return ''

    df['Device Type'] = df.apply(get_device_type, axis=1)

    # Combine hospital code, address, floor, section, and device type to create a unique floor identifier
    df['Unique Floor'] = df['Hospital Code'] + df['Address'] + df['Floor'].astype(str) + df['Section'].astype(str) + df['Device Type']

    # Group the records by unique floor identifier
    floor_groups = df.groupby('Unique Floor')

    # Assign sequential designators
    df['Suggested Designator'] = floor_groups.cumcount() + 1

    # Handle cases with NaN values
    df['Unique Floor'].fillna('Unresolved', inplace=True)
    df['Suggested Designator'].fillna('Unresolved', inplace=True)

    # Save the updated DataFrame to a new Excel file
    output_file_name = f'output_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
    df.to_excel(output_file_name, index=False)

    print(f'Updated data saved to {output_file_name}')

generate_sequential_designators('LHGV-NOV3.xlsx')
