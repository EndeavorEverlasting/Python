# Utlizes cells only to help phase out pandas

def monitorIssues(self, data):
response = ""

# Get the column indices for the required columns
type_col_index = self.df.columns.get_loc('Type')
ws_mon_make_1_col_index = self.df.columns.get_loc('WS_Mon_Make_1')
ws_mon_mod_1_col_index = self.df.columns.get_loc('WS_Mon_Mod_1')
mon_1_col_index = self.df.columns.get_loc('Mon 1')

try:
    # Check if the 'Type' column is not NaN and is one of the specified values
    if pd.notna(data[type_col_index]) and str(data[type_col_index]).lower() in ["workstation", "laptop", "desktop"]:

        # Check if 'WS_Mon_Make_1' is NaN
        if not pd.notna(data[ws_mon_make_1_col_index]):
            response += " needs a monitor make"

        # Check if 'WS_Mon_Mod_1' is NaN
        if not pd.notna(data[ws_mon_mod_1_col_index]):
            response += " needs a monitor model"

        # Check if 'Mon 1' is NaN or 0
        if not pd.notna(data[mon_1_col_index]) or int(data[mon_1_col_index]) == 0:
            response += " needs a monitor size"

    if response != "":
        self.monitor_Issues.append(data[self.df.columns.get_loc("ID")])

except KeyError as e:
    print(f"KeyError: {e}, Row Data: {data.values.tolist()}")

return response
