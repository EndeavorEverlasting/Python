import pandas as pd
from datetime import datetime


def find_duplicates_and_missing_data(input_file):
  # Get the current date
  current_date = datetime.now().strftime('%Y-%m-%d')

  # Get the current time in military format
  current_time = datetime.now().strftime('%H%M%S')

  # Read the Excel file
  df = pd.read_excel(input_file, skiprows=1)

  # Find records where both 'Flr Pln N' and 'Flr Pln D' match on two or more occurrences
  duplicates_n_d = df.groupby(['Flr Pln N',
                               'Flr Pln D']).filter(lambda x: len(x) >= 2)

  # Find records where both 'Flr Pln D' and 'Department' match on two or more occurrences
  duplicates_d_id = df.groupby(['Flr Pln D',
                                'Department']).filter(lambda x: len(x) >= 2)

  # Find records where both 'Flr Pln D' and 'Flr Pln L' match on two or more occurrences
  dupe_d_l = df.groupby(['Flr Pln D',
                         'Flr Pln L']).filter(lambda x: len(x) >= 2)

  # Concatenate the results
  duplicates = pd.concat([duplicates_n_d, duplicates_d_id, dupe_d_l],
                         ignore_index=True)

  # Remove duplicates based on 'ID' column
  duplicates = duplicates.drop_duplicates(subset=['ID'])

  # Find records with missing data in a specific column (e.g., 'Flr Pln N')
  missing_data = df[df['Flr Pln N'].isna()]

  # Filter entries where "Flr Pln D" does not start with "P" or "S"
  entries_to_include = df[~df['Flr Pln D'].str.startswith(('P', 'S'))]

  # Check if "WS_Mon_Make_1" and "WS_Mon_Mod_1" are blank
  entries_to_include = entries_to_include[
      (entries_to_include['WS_Mon_Make_1'].isna()
       | entries_to_include['WS_Mon_Make_1'].eq(''))
      & (entries_to_include['WS_Mon_Mod_1'].isna()
         | entries_to_include['WS_Mon_Mod_1'].eq(''))]

  # Concatenate duplicates, filtered entries, and missing data
  combined_data = pd.concat([duplicates, missing_data, entries_to_include],
                            ignore_index=True)

  # Remove duplicates based on 'ID' column
  combined_data = combined_data.drop_duplicates(subset=['ID'])

  if not combined_data.empty:
    # Add a new column for unique identifier (assuming you have some identifier)
    combined_data.insert(0, 'Unique Identifier',
                         range(1,
                               len(combined_data) + 1))

    # Output combined data with file name and time in the file name
    output_file = f'combined_data_{input_file}_{current_time}.csv'
    combined_data.to_csv(output_file, index=False)
    print(f'Data saved in {output_file}')
  else:
    print('No data found.')


# Example usage
input_file = 'LHGV 1101 (WORKSTATIONS).xlsx'
find_duplicates_and_missing_data(input_file)
