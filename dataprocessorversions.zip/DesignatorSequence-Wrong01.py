import pandas as pd
from datetime import datetime

def generate_sequential_designators(input_file):
  df = pd.read_excel(input_file, skiprows=1)

  # Extract the hospital code and floor information from "Flr Pln N"
  df['Hospital Code'] = df['Flr Pln N'].str.extract(r'([A-Z]+[h,a])-')

  # Extract floor and section numbers
  floor_info = df['Flr Pln N'].str.extract(r'Floor\s*(\d+)-Section\s*(\d+)')
  df['Floor'] = floor_info[0].astype(float).fillna(0).astype(int)  # Convert to float, fill missing values with 0, then convert to int
  df['Section'] = floor_info[1].astype(float).fillna(0).astype(int)  # Convert to float, fill missing values with 0, then convert to int

  # Combine hospital code and floor number to create a unique floor identifier
  df['Unique Floor'] = df['Hospital Code'] + df['Floor'].astype(str)

  # Group the records by unique floor identifier
  floor_groups = df.groupby('Unique Floor')

  # Assign sequential designators
  df['Suggested Designator'] = floor_groups.cumcount() + 1

  # Save the updated DataFrame to a new Excel file
  output_file_name = f'output_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
  df.to_excel(output_file_name, index=False)

  print(f'Updated data saved to {output_file_name}')

work_bitch = generate_sequential_designators(r'LHGV-NOV3.xlsx')
