import os
import pandas as pd
from datetime import datetime


def find_duplicates_and_missing_data(input_file):
  # Get the current date
  current_date = datetime.now().strftime('%Y-%m-%d')

  # Get the current time in military format
  current_time = datetime.now().strftime('%H%M%S')

  # Read the Excel file
  df = pd.read_excel(input_file, skiprows=1)

  # Clean up 'Flr Pln D' column by removing leading and trailing spaces
  df['Flr Pln D'] = df['Flr Pln D'].str.strip()

  # Check for incorrect designators first
  entries_with_incorrect_designator = df[~df['Flr Pln D'].str[0].str.isalpha()]

  # Find records where both 'Flr Pln N' and 'Flr Pln D', New URL and Designator, match on two or more occurrences
  duplicates_n_d = df.groupby(['Flr Pln N',
                               'Flr Pln D']).filter(lambda x: len(x) >= 2)

  # Find records where both 'Flr Pln D' and 'Department', Department and Designator,
  # match on two or more occurrences
  duplicates_d_id = df.groupby(['Flr Pln D',
                                'Department']).filter(lambda x: len(x) >= 2)

  # Find records where both 'Flr Pln D' and 'Flr Pln L', Old URL and Designator,
  # match on two or more occurrences
  dupe_d_l = df.groupby(['Flr Pln D',
                         'Flr Pln L']).filter(lambda x: len(x) >= 2)

  # Concatenate the results
  duplicates = pd.concat([duplicates_n_d, duplicates_d_id, dupe_d_l],
                         ignore_index=True)

  # Remove duplicates based on 'ID' column
  duplicates = duplicates.drop_duplicates(subset=['ID'])

  # Find records with missing data in the Floor Plan URL column (e.g., 'Flr Pln N')
  # This will be used when I build functionality
  # to fill in a column based on available data
  missing_data = df[df['Flr Pln N'].isna()]

  # Filter entries where "Flr Pln D" does not start with "P" or "S".
  # This logic should record entries without a floor plan designator
  entries_to_include = df[~df['Flr Pln D'].str.startswith(('P', 'S'))]

  # Check if "WS_Mon_Make_1" and "WS_Mon_Mod_1", the monitor Make and Model, are blank
  # This logic records records missing Monitor Information:
  entries_to_include = entries_to_include[
      (entries_to_include['WS_Mon_Make_1'].isna()
       | entries_to_include['WS_Mon_Make_1'].eq('')) |
      (entries_to_include['WS_Mon_Mod_1'].isna()
       | entries_to_include['WS_Mon_Mod_1'].eq(''))]

  # Concatenate duplicates, filtered entries, and missing data
  combined_data = pd.concat([
      entries_with_incorrect_designator, duplicates, missing_data,
      entries_to_include
  ],
                            ignore_index=True)

  # Remove duplicates based on 'ID' column
  combined_data = combined_data.drop_duplicates(subset=['ID'])

  if not combined_data.empty:
    # Add a new column for unique identifier (assuming you have some identifier)
    combined_data.insert(0, 'Unique Identifier',
                         range(1,
                               len(combined_data) + 1))

    # ... (previous code)

    # Define a function to determine flagging reason
    def determine_flagging_reason(row):
      reasons = []

      if not pd.notna(row['Flr Pln N']):
        reasons.append('Missing Flr Pln N')
      if pd.notna(row['Flr Pln D']) and pd.notna(row['Department']):
        reasons.append('Duplicate based on Flr Pln D and Department')
      if pd.notna(row['Flr Pln D']) and pd.notna(row['Flr Pln L']):
        reasons.append('Duplicate based on Flr Pln D and Flr Pln L')
      if row['Flr Pln D'].startswith(
          ('L', 'W')) and (row['WS_Mon_Make_1'] in (None, '')
                           or row['WS_Mon_Mod_1'] in (None, '')):
        reasons.append('Incorrect Monitor Info')

      if reasons:
        return ', '.join(reasons)
      else:
        return 'Unknown Reason'

    # Apply the function to create the flagging reason column
    combined_data['Flagging Reason'] = combined_data.apply(
        determine_flagging_reason, axis=1)

    # Output filtered records to file:
    # Get the file name without extension
    file_name = os.path.splitext(input_file)[0]

    # Output combined data with modified file name and time in the file name
    output_file = f'combined_data_{file_name}_{current_time}.csv'
    combined_data.to_csv(output_file, index=False)
    print(f'Data saved in {output_file}')
  else:
    print('No data found.')


# Example usage
input_file = 'LHGV-NOV3.xlsx'
find_duplicates_and_missing_data(input_file)
