'''

This document will run all of the other script components.

'''
# mainest_script.py

from data_processing import process_data

# Call the function
process_data(file_path='your_file.xlsx')
