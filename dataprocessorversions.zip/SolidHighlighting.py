import os, sys, logging, re
import pandas as pd
from shutil import copy2
#from typing import Union
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill


class DataProcessor:

  def __init__(self, input_file="lij 1.12.24.xlsx"):
    self.df = None
    self.wb = None
    self.input_file = input_file
    self.output_file = None
    self.duplicates = []  # Added attribute for duplicates
    self.incorrect_designators = [
    ]  # Added attribute for incorrect designators
    self.missing_floorplans = []
    self.monitor_Issues = []
    #self.floorplan = floorPlanIssues(row)

    # Ensure the existence of the 'logs' directory
    logs_dir = 'logs'
    os.makedirs(logs_dir, exist_ok=True)

    # Set up logging
    self.setup_logging()

    # Load data in the constructor
    self.load_data()

  # Set up logging logic:
  # The following message format string will log the debugging data in a log file.
  # It's in the folowing standard format:
  # 1) time
  # 2) the severity of the message, and
  # 3) the contents of the message, in that order:
  def setup_logging(self):
    # Specify the root folder for outputs
    output_folder = 'Outputs/'

    # Create the output directory if it doesn't exist
    output_directory = os.path.join(output_folder, 'logs')
    os.makedirs(output_directory, exist_ok=True)

    # Set up logging
    log_file = os.path.join('Outputs', 'logs', 'data_processor.log')
    logging.basicConfig(
        filename=log_file,  # Set the log file name
        level=logging.INFO,  # Set the logging level to INFO
        format='%(asctime)s - %(levelname)s - %(message)s')  # format 3

  def load_data(self):
    self.wb = load_workbook(self.input_file, read_only=False, data_only=False)
    self.df = pd.read_excel(self.input_file, skiprows=1, engine='openpyxl')

  def determine_output_files(self):
    # Start of determine_output_files()
    logging.info(f"Beginning the determine_output_files(): {self.output_file}")

    # Specify the root folder for outputs
    output_folder = 'Outputs/'

    # Generate dynamic output file name based on date and time
    current_datetime = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Determine file type based on the extension of the input file

    file_extension = os.path.splitext(self.input_file)[1].lower()
    if file_extension == '.csv':
      file_type = 'csv'
    elif file_extension == '.xlsx':
      file_type = 'ss'
    elif file_extension == '.txt':
      file_type = 'txt'
    elif file_extension == '.log':
      file_type = 'logs'
    else:
      # Default to 'ss' if the file type is not recognized
      file_type = 'ss'

    # Create the output directory if it doesn't exist
    output_directory = os.path.join(output_folder, file_type)
    os.makedirs(output_directory, exist_ok=True)

    # Generate the output file name
    self.output_file = f"{output_folder}{file_type}/output_{current_datetime}.xlsx"

    # Check if the output_file already exists
    # Increase the counter in case I mix objects and risk overwriting
    counter = 1
    while os.path.exists(self.output_file):
      self.output_file = (str(output_folder) + str(file_type) + "/output_" +
                          str(current_datetime) + "_" + str(counter) + ".xlsx")

      counter += 1

      # Load the workbook for the output file
      # Check if the workbook already exists
      if not os.path.exists(self.output_file):
        try:
          # Try to copy the input workbook
          copy2(self.input_file, self.output_file)
        except Exception as copy_error:
          # If copying fails, create an empty workbook
          logging.warning(f"Copying input workbook failed. "
                          f"Creating an empty workbook. Error: {copy_error}")

          self.wb = Workbook()

          # Add a default worksheet (customizable)
          if not self.wb.sheetnames:
            self.wb.create_sheet(title="CreatedSheet1")

          # Save the workbook
          self.wb.save(self.output_file)
    # End of determine_output_files()

    # Missing the actual creation of the copy of the workbook
    logging.info(f"Creating a copy of the input data: {self.output_file}")

    # End of determine_output_files()
    logging.info(f"Ending the determine_output_files(): {self.output_file}")

  def floorPlanIssues(self, data):
    response = ""
    plan_n = data['Flr Pln N']
    plan_l = data['Flr Pln L']
    if (not pd.notna(plan_n)) and (not pd.notna(plan_l)):
      self.missing_floorplans.append(data["ID"])
      response = " needs a floorplan"
    return response

  def designatorIssues(self, data):
    try:
      response = ""
      des = data['Flr Pln D']
      if not pd.notna(des):
        self.incorrect_designators.append(data[des])
        response = " needs a designator"
    except Exception as e:
      print(f"{e}\n{sys.exc_info()[-1].tb_lineno}")
    return response

  def monitorIssues(self, data):
    #missing monitors or the monitor's wrong size what ever issues with it
    response = ""
    # The following block is suscpetible to errors
    # because of the way the data is formatted.
    # There might be a blank or an empty string in the data.
    # We'll try and catch the logic to handle the error acutely.
    try:
      # print(f"Row Type: {str(data['Type']).lower()}")
      if (str(data['Type']).lower() in "workstation,laptop,desktop") \
          and (data["ID"] not in self.monitor_Issues):
        # print(f"Values in data: {data.values.tolist()}")
        if not pd.notna(data['WS_Mon_Make_1']):
          response += " needs a monitor make"
        if not pd.notna(data['WS_Mon_Mod_1']):
          response += " needs a monitor model"
        # size is a number stored as a string so
        # we need to typecast it to an integer and check if it equals zero
        if not pd.notna(data['Mon 1']) or int(data['Mon 1']) == 0:
          response += " needs a monitor size"
      if response != "":
        self.monitor_Issues.append(data["ID"])
    except KeyError as e:
      print(f"KeyError: {e}, Row Data: {data.values.tolist()}")
    return response

  def flaggingIssues(self, mon, desi, floor, row):
    #adds the issue from the called function to the data and file it
    return f"{row['ID']} {mon} {desi} {floor}"

  def check_duplicate_designators(self, data):
    # Logic for finding duplicate designators
    # Read the Excel file
    #self.df = pd.read_excel(self.input_file, skiprows=1, engine='openpyxl')

    # Clean up 'Flr Pln D' column by removing leading and trailing spaces
    #self.df['Flr Pln D'] = self.df['Flr Pln D'].str.strip()
    #this line iterates over each row to get its single data for that row
    try:
      firstIds = []
      checklis = []
      IDs_of_Duplicates = []
      finder = []
      for i, r in data.iterrows():
        # Sometimes, a user will mark a record as "NOT FOUND" in Flr Pln D
        # Other times, a user with mark a device as remote and will not input a designator
        # Skip such cases in search for duplicates:
        if str(r['Flr Pln D']).lower() or str(
            r['EPIC_LOC']).lower() not in "not found":
          condition_1 = f"{r['Flr Pln D']}/{r['Flr Pln N']}"
          condition_2 = f"{r['Flr Pln D']}/{r['Flr Pln L']}"
          condition_3 = f"{r['Flr Pln D']}/{r['Department']}"
          if condition_1 not in str(checklis) or condition_2 not in str(
              checklis) or condition_3 not in str(checklis):
            firstIds.append(str(r['ID']))
            checklis.append(condition_1 + condition_2 + condition_3)
          else:
            IDs_of_Duplicates.append(str(r['ID']))
            finder.append(condition_1 + condition_2 + condition_3)
      for f in finder:
        if f in checklis:
          n = checklis.index(f)
          self.duplicates.append(
              f"{firstIds[n]} is duplicates with {IDs_of_Duplicates[finder.index(f)]}"
          )
      if self.duplicates:
        # Highlight the duplicates as tuples in the output file
        self.highlight_duplicate_des(self.duplicates[0])
      return None

    except Exception as e:
      print(f"{e}\n{sys.exc_info()[-1].tb_lineno}")
    return None

  def output_function(self):
    try:
      for index, row in self.df.iterrows():
        print(f"Processing row {index} of {len(self.df)}")
        designator = row['Flr Pln D']
        epic_loc = row['EPIC_LOC']
        department = row['Department']
        newFloorplan = row['Flr Pln N']
        oldFloorplan = row['Flr Pln L']

        monitor = self.monitorIssues(row)
        designator = self.designatorIssues(row)
        floorplan = self.floorPlanIssues(row)
        print(self.flaggingIssues(monitor, designator, floorplan, row))
        # See list of incorrect designators:
        #print(f'Incorrect Designators: {len(self.incorrect_designators)}')
        #print(f'Duplicates: {len(duplicates)}')
        #print(f'Missing Data: {len(missing_floorplans)}')
        #print(f'Monitor Makes Missing: {len(missing_makes)}')
        #Add cases for models and sizes
        #Highlight discrepancies for users:
        #self.highlight_duplicate_des([])  # Corrected method call
      print(self.duplicates)
      return None
    except Exception as e:
      # write to the log file
      print(f"{e}\n{sys.exc_info()[-1].tb_lineno}")

  def highlight_duplicate_des(self, duplicate_message):
    logging.info(
        f"Beginning of highlight_duplicate_des(self, duplicates): {self.output_file}"
    )
    try:
      # Check if workbook and sheetnames exist.
      if self.wb is not None and self.wb.sheetnames:
        sheet_name = self.wb.sheetnames[0]
        sheet = self.wb[sheet_name]
        new_id = None
        existing_id = None

        # Extract IDs from the message generated in check_duplicate_designators()
        ids = re.findall(r'\d+', duplicate_message)
        if len(ids) == 2:
          new_id, existing_id = map(int, ids)

          # Find the row index for the new_id
          new_id_row = None
          for row_index in range(2, sheet.max_row + 1):
            current_id_cell = sheet.cell(row=row_index, column=1)
            current_id_value = current_id_cell.value
            if current_id_value == new_id:

              try:
                # Attempt to convert the current ID to an integer
                current_id = int(current_id_value)
              except (ValueError, TypeError):
                # Handle cases where 'ID' value is not a valid integer
                current_id = None
              if current_id == new_id:
                new_id_row = row_index
                break

          #Check if the new_id_row is found
          if new_id_row is not None:
            # Apply red fill to the cell
            for col_index in range(2, sheet.max_column + 1):
              cell = sheet.cell(row=row_index, column=col_index)
              cell.fill = PatternFill(start_color='FF0000',
                                      end_color='FF0000',
                                      fill_type='solid')

            # Save the workbook
            self.wb.save(filename=self.output_file)
            print(f"File Has Been Updated in {self.output_file}")

        else:
          logging.warning("Issue with the number of IDs.")

      else:
        logging.warning("Workbook is not defined. Unable to save.")

    except Exception as e:
      print(f"Error occurred while highlighting duplicates: {e}")

    finally:
      logging.info(
          f"Ending of highlight_duplicate_des(self, duplicate_message): "
          f"{self.output_file}")

  def process_data(self):

    # Log beginning of process_data()
    logging.info(
        f"Beginning of process_data(self, duplicates): {self.output_file}")

    try:
      self.load_data()
      # generate an output file based on the input file
      self.determine_output_files()

      #Begin Processing Discrepancies:
      self.check_duplicate_designators(self.df)

      logging.info(
          f"Highlighting duplicates in the output file: {self.output_file}")
      # Highlight duplicates in the output file
      self.highlight_duplicate_des(self.duplicates)

    except Exception as e:
      print(f"An error occurred while processing data: {e}")
      logging.error(f"An error occurred in process_data: {e}")

    finally:
      # Log end of process_data()
      logging.info(
          f"Ending of process_data(self, duplicates): {self.output_file}")

  def process_multiple_files(self, input_folder, output_folder):
    pass


# Run the current data procesor
data_processor = DataProcessor().process_data()

# Configure logging to write messages/logs to a file
logging.basicConfig(filename='data_processing.log', level=logging.INFO)
