import pandas as pd

def generate_sequential_designators(input_file):
    # Read the input data
    df = pd.read_excel(input_file, skiprows=1)

    # Filter data based on conditions (e.g., Hostname, Type)
    workstation_data = df[df['Hostname'].str.startswith('W') & df['Hostname'].notna()]
    laptop_data = df[df['Hostname'].str.startswith('L') & df['Hostname'].notna()]
    printer_data = df[df['Type'] == 'Printer']

    # Group by Floor and Building
    for floor, floor_data in df.groupby(['Flr Pln N', 'Flr Pln L']):
        # Workstations
        workstation_data_floor = workstation_data[
            (workstation_data['Flr Pln N'] == floor[0]) &
            (workstation_data['Flr Pln L'] == floor[1])
        ]
        workstation_max = workstation_data_floor['Flr Pln D'].str.extract('(\d+)').astype(float).max()
        workstation_suggestion = f'W{int(workstation_max) + 1}' if pd.notna(workstation_max) else 'W1'

        # Laptops
        laptop_data_floor = laptop_data[
            (laptop_data['Flr Pln N'] == floor[0]) &
            (laptop_data['Flr Pln L'] == floor[1])
        ]
        laptop_max = laptop_data_floor['Flr Pln D'].str.extract('(\d+)').astype(float).max()
        laptop_suggestion = f'L{int(laptop_max) + 1}' if pd.notna(laptop_max) else 'L1'

        # Printers
        printer_data_floor = printer_data[
            (printer_data['Flr Pln N'] == floor[0]) &
            (printer_data['Flr Pln L'] == floor[1])
        ]
        printer_max = printer_data_floor['Flr Pln D'].str.extract('(\d+)').astype(float).max()
        printer_suggestion = f'P{int(printer_max) + 1}' if pd.notna(printer_max) else 'P1'

        # Update the dataframe with suggested designators
        df.loc[workstation_data_floor.index, 'Suggested Designator'] = workstation_suggestion
        df.loc[laptop_data_floor.index, 'Suggested Designator'] = laptop_suggestion
        df.loc[printer_data_floor.index, 'Suggested Designator'] = printer_suggestion

    # Save the updated dataframe
    output_file_name = 'output.xlsx'
    df.to_excel(output_file_name, index=False)

# Example usage
input_file = 'LHGV-NOV3.xlsx'
generate_sequential_designators(input_file)
