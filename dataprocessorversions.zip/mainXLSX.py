# This script will take an excel spreadsheet and go through of column of choosing
# -- returning all of the duplicates with a unique identifier for the the record.

import pandas as pd
from datetime import datetime

##### ##### ##### ##### #####

# For the purpose of ITAMming, the spreadsheet should be modified to have
# column names without spaces.
#Three essential columns for ITAMing: A: ID, L: FlrPlnN, M: FlrPlnD

##### ##### ##### ##### #####

# Features to add:
# Output Record ID
# Check if floor plans are equal before qualifying record as a duplicate


def print_column_names(input_file):
  df = pd.read_excel(input_file, skiprows=1)
  print(df.columns)


def find_duplicates(input_file):
  # Read the Excel file
  df = pd.read_excel(input_file, skiprows=1)

  # Find duplicates based on the chosen column
  duplicates_n = df[df.duplicated(subset=['FlrPlnN'], keep=False)]
  duplicates_d = df[df.duplicated(subset=['FlrPlnD'], keep=False)]
  duplicates_dept = df[df.duplicated(subset=['Department'], keep=False)]

  # Find records that are duplicates in both 'FlrPlnN' and 'FlrPlnD'
  duplicates = pd.merge(duplicates_n, duplicates_d, how='inner')
  duplicates = pd.merge(duplicates,  duplicates_dept, how='inner')

  if not duplicates.empty:
      # Add a new column for unique identifier (assuming you have some identifier)
      duplicates.insert(0, 'Unique Identifier', range(1, len(duplicates) + 1))

      # Get the current date
      current_date = datetime.now().strftime('%Y-%m-%d')

      # Output duplicates with date in the file name
      output_file = f'duplicates_DeptND_{input_file}_{current_date}.csv'
      duplicates.to_csv(output_file, index=False)
      print(f'Duplicates found and saved in {output_file}')
  else:
      print('No duplicates found.')

# Example usage
input_file = 'Lenox Health Greenwich.xlsx'

find_duplicates(input_file)

