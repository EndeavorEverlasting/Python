import os
import pandas as pd
from datetime import datetime

# Example usage:
# Determine Input File:
input_file = 'NWH-NOV8.xlsx'
# Read the Excel file
df = pd.read_excel(input_file, skiprows=1)

current_time = datetime.now().strftime('%H%M%S')

print("declaring variables. . .")
# Prevent Arrays Useful Across Different Functions from Being Ubound
duplicates_d_dept = []
duplicates_d_l = []
duplicates_d_n = []
duplicates_n_d = []


def find_duplicates_and_missing_data(input_file):
  """
    This function identifies and processes
    duplicate records, missing data, and 
    incorrect designators in an Excel file.

    Args:
        input_file (str): Path to the input Excel file.

    Returns:
        None
    """

  # Check for incorrect designators
  # old line with cool code:
  # incorrect_designators = df[~df['Flr Pln D'].str.match(r'^[A-Z]\d+$')]
  incorrect_designators = df[~df['Flr Pln D'].str.match(r'^[A-Z]+\d+$')]

  # Check for incorrect designators
  incorrect_designators = []
  for index, row in df.iterrows():

    designator = row['Flr Pln D']
    epic_loc = row['EPIC_LOC']

    # Logic for checking incorrect designators:
    # if the entry is not NaN and is a string that reads, "remote," skip the entry:
    # Logic for checking incorrect designators:
    if pd.notna(epic_loc) and isinstance(epic_loc,
                                         str) and 'remote' in epic_loc.lower():
      continue  # Skip records where 'remote' is present in 'EPIC_LOC'

    if pd.notna(designator) and (not isinstance(designator, str)
                                 or not designator[0].isalpha()
                                 or not designator[1:].isdigit()):
      incorrect_designators.append(index)

  print("Inputting designators to Incorrect Desig Dataframe")
  incorrect_designators_df = pd.DataFrame(
      incorrect_designators, columns=['Incorrect Designator Index'])

  # Replace the placeholder value with NaN
  df['Flr Pln D'].replace('placeholder', float('nan'), inplace=True)

  # The next area contains code with bugs; you will see false flags in the output.
  # Items are counted as having the problem, but
  # the records show they shouldn't have been counted.
  '''
    # NEXT SECTION: DUPLICATES
    # Identify duplicate records
  '''

  for index, row in df.iterrows():
    #Instantiate Variables for Processing:
    designator = row['Flr Pln D']
    department = row['Department']
    newFlrPln = row['New Flr Pln']
    oldFlrPln = row['Flr Pln L']

    # Process the DataFrame for Misinformation:

    # Department and Designator Duplicate Logic:
    # Find records where both 'Flr Pln D' and 'Flr Pln L', Old URL and Designator,
    # match on two or more occurrences
    # if the Designator is NaN, skip the iteration

    print("Duplicates")
    if pd.notna(designator) and pd.notna(oldFlrPln):
      if any((d['Flr Pln D'] == designator) & (d[oldFlrPln == 'Flr Pln L'])
             for d in duplicates_d_dept):
        duplicates_d_l.append(row)
        print("Old Floor x Designator Dupe: ", designator)
      else:
        print(f'Valid Record: {designator}\t{oldFlrPln}')

    # Check if both Flr Pln D and Department are not NaN
    if pd.notna(designator) and pd.notna(department):
      # Check if this combination already exists in the duplicates list
      if any((d['Flr Pln D'] == designator) & (d['Department'] == department)
             for d in duplicates_d_dept):
        duplicates_d_dept.append(row)
        print("Department x Designator Dupe: ", department)

      else:
        print(f'Valid Record: {designator}\t{department}')

        # Find records where both 'Flr Pln N' and 'Flr Pln D', New URL and Designator,
        # match on two or more occurrences
        # Check for duplicates based on 'Flr Pln D' and 'Flr Pln N'
        if pd.notna(designator) and pd.notna(newFlrPln):
          if any((d['Flr Pln D'] == designator) & (d['Flr Pln N'] == newFlrPln)
                 for d in duplicates_n_d):
            duplicates_n_d.append(row)
            print("New Floor x Designator Dupe: ", designator)

          else:
            print(f'Valid Record: {designator}\t{newFlrPln}')
  print('Duplicates Dataframe Construction Complete')

  # Concatenate the results
  duplicates = pd.concat([duplicates_n_d, duplicates_d_dept, duplicates_d_l],
                         ignore_index=True)

  # Find records with missing data in the Floor Plan URL column (e.g., 'Flr Pln N')
  missing_data = df[df['Flr Pln N'].isna()]

  # Filter entries where "Flr Pln D" does not start with "P" or "S",
  # or is not in the format of a letter followed by a number
  entries_to_include = df[~(df['Flr Pln D'].str.startswith(
      ('P', 'S')) | df['Flr Pln D'].str.match(r'^[A-Z]\d+$'))]

  # Check if "WS_Mon_Make_1" and "WS_Mon_Mod_1", the monitor Make and Model, are blank
  entries_to_include = entries_to_include[
      (entries_to_include['WS_Mon_Make_1'].isna()
       | entries_to_include['WS_Mon_Make_1'].eq('')) |
      (entries_to_include['WS_Mon_Mod_1'].isna()
       | entries_to_include['WS_Mon_Mod_1'].eq(''))]

  # Check the length of each dataframe
  print(f'Incorrect Designators: {len(incorrect_designators_df)}')
  print(f'Duplicates: {len(duplicates)}')
  print(f'Missing Data: {len(missing_data)}')
  print(f'Entries to Include: {len(entries_to_include)}')

  # Concatenate all identified records
  combined_data = pd.concat([
      df.loc[incorrect_designators_df['Incorrect Designator Index']],
      duplicates,
      missing_data,
      entries_to_include,
  ],
                            ignore_index=True)

  if not combined_data.empty:
    # Add a new column for unique identifier (assuming you have some identifier)
    combined_data.insert(0, 'Unique Identifier',
                         range(1,
                               len(combined_data) + 1))

    # Add a new column 'Flr Pln D String' to store 'Flr Pln D' as strings
    combined_data['Flr Pln D String'] = combined_data['Flr Pln D'].astype(str)

    # Define a function to determine flagging reason
    def determine_flagging_reason(row):
      reasons = []

      if not pd.notna(row['Flr Pln N']):
        reasons.append('Missing New Floor Plan')
      if pd.notna(row['Flr Pln D']) and pd.notna(row['Department']):
        reasons.append('Duplicate based on Designator and Department')
      if pd.notna(row['Flr Pln D']) and pd.notna(row['Flr Pln L']):
        reasons.append('Duplicate based on Designator  and New Floor Plan')

      designator = row['Flr Pln D String']

      if designator.startswith(
          ('L', 'W')) and (not pd.notna(row['WS_Mon_Make_1'])
                           or not pd.notna(row['WS_Mon_Mod_1'])):
        reasons.append('Incorrect Monitor Info')

      if not isinstance(
          designator,
          str) or not designator[0].isalpha() or not designator[1:].isdigit():
        reasons.append('Incorrect Designator Info')

      if reasons:
        return ', '.join(reasons)
      else:
        return 'Unknown Reason'

    # Apply the function to create the flagging reason column
    combined_data['Flagging Reason'] = combined_data.apply(
        determine_flagging_reason, axis=1)

    # Add a new column 'Reasons' to store flagging reasons
    combined_data.insert(0, 'Reasons to Correct Entry',
                         combined_data['Flagging Reason'])

    # Remove the 'Flagging Reason' column
    # combined_data = combined_data.drop(columns=['Flagging Reason'])

    # Output flagging reasons for debugging
    print(combined_data[['Flr Pln D', 'Flagging Reason']])

    # Output filtered records to file:
    # Get the file name without extension
    file_name = os.path.splitext(input_file)[0]

    # Output combined data with modified file name and time in the file name
    output_file_name = f'{file_name}_{current_time}.csv'
    combined_data.to_csv(output_file_name, index=False)
    # Inform the user about the generated CSV file
    print(f'CSV file "{output_file_name}" generated successfully.')

  # Execute Processing Logic:
  find_duplicates_and_missing_data(input_file)

  # Notify the user that the script has run successfully


"""
Develop functionality to check each floor plan for repeating designators

"""
